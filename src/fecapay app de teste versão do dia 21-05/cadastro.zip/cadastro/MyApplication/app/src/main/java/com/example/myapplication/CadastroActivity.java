package com.example.myapplication;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CadastroActivity extends AppCompatActivity {

    private EditText editNome, editCurso, editSemestre, editCPF, editRA, editNascimento, editEmail, editSenha;
    private Button btnSignIn;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro); // Substitua pelo nome real do seu arquivo XML, sem .xml. Ex: R.layout.activity_cadastro

        // Inicializa os componentes
        editNome = findViewById(R.id.editNome);
        editCurso = findViewById(R.id.editCurso);
        editSemestre = findViewById(R.id.editSemestre);
        editCPF = findViewById(R.id.editCPF);
        editRA = findViewById(R.id.editRA);
        editNascimento = findViewById(R.id.editNascimento);
        editEmail = findViewById(R.id.editEmail);
        editSenha = findViewById(R.id.editSenha);
        btnSignIn = findViewById(R.id.btnSignIn);

        dbHelper = new DatabaseHelper(this);

        // Botão de cadastro
        btnSignIn.setOnClickListener(v -> {
            // Coleta os dados
            String nome = editNome.getText().toString();
            String curso = editCurso.getText().toString();
            String semestre = editSemestre.getText().toString();
            String cpf = editCPF.getText().toString();
            String ra = editRA.getText().toString();
            String nascimento = editNascimento.getText().toString();
            String email = editEmail.getText().toString();
            String senha = editSenha.getText().toString();

            // Verifica se todos os campos estão preenchidos
            if (nome.isEmpty() || curso.isEmpty() || semestre.isEmpty() ||
                    cpf.isEmpty() || ra.isEmpty() || nascimento.isEmpty() ||
                    email.isEmpty() || senha.isEmpty()) {
                Toast.makeText(this, "Preencha todos os campos.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Insere no banco
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(DatabaseHelper.COLUMN_NOME, nome);
            values.put(DatabaseHelper.COLUMN_CURSO, curso);
            values.put(DatabaseHelper.COLUMN_SEMESTRE, semestre);
            values.put(DatabaseHelper.COLUMN_CPF, cpf);
            values.put(DatabaseHelper.COLUMN_RA, ra);
            values.put(DatabaseHelper.COLUMN_NASCIMENTO, nascimento);
            values.put(DatabaseHelper.COLUMN_EMAIL, email);
            values.put(DatabaseHelper.COLUMN_SENHA, senha);

            long id = db.insert(DatabaseHelper.TABLE_USUARIOS, null, values);

            if (id != -1) {
                Toast.makeText(this, "Cadastro realizado com sucesso!", Toast.LENGTH_SHORT).show();
                // Vai para LoginActivity
                Intent intent = new Intent(CadastroActivity.this, LoginActivity.class);
                startActivity(intent);
                finish(); // Fecha a tela de cadastro
            } else {
                Toast.makeText(this, "Erro ao salvar no banco.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
