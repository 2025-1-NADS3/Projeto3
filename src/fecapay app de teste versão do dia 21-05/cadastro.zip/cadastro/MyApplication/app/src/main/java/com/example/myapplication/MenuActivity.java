package com.example.myapplication;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;


public class MenuActivity extends AppCompatActivity {


    RelativeLayout cardAviso;
    ImageView btnFechar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);


        // Inicializa o card e botão de fechar
        cardAviso = findViewById(R.id.card_aviso);
        btnFechar = findViewById(R.id.btn_fechar);


        // Fecha o aviso ao clicar no "X"
        btnFechar.setOnClickListener(v -> cardAviso.setVisibility(View.GONE));


        // Exemplo: ações ao clicar nos botões (opcional)
        Button btnPerfil = findViewById(R.id.btn_perfil);
        btnPerfil.setOnClickListener(v ->
                Toast.makeText(this, "Abrindo Perfil...", Toast.LENGTH_SHORT).show());


        // Repita se quiser usar os outros botões
    }
}

