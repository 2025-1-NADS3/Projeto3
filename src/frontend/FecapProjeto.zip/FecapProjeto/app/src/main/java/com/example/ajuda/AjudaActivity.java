package com.example.ajuda; // substitua com o nome do seu pacote

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;

public class AjudaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ajuda); // certifique-se de que o nome do XML é esse

        // FAQ 1
        LinearLayout faq1 = findViewById(R.id.faq_item_1);
        LinearLayout resposta1 = findViewById(R.id.resposta_1);
        faq1.setOnClickListener(v -> toggleResposta(resposta1));

        // FAQ 2
        LinearLayout faq2 = findViewById(R.id.faq_item_2);
        LinearLayout resposta2 = findViewById(R.id.resposta_2);
        faq2.setOnClickListener(v -> toggleResposta(resposta2));

        // FAQ 3
        LinearLayout faq3 = findViewById(R.id.faq_item_3);
        LinearLayout resposta3 = findViewById(R.id.resposta_3);
        faq3.setOnClickListener(v -> toggleResposta(resposta3));

        // FAQ 4
        LinearLayout faq4 = findViewById(R.id.faq_item_4);
        LinearLayout resposta4 = findViewById(R.id.resposta_4);
        faq4.setOnClickListener(v -> toggleResposta(resposta4));
    }

    private void toggleResposta(LinearLayout resposta) {
        if (resposta.getVisibility() == View.GONE) {
            resposta.setVisibility(View.VISIBLE);
        } else {
            resposta.setVisibility(View.GONE);
        }
    }
}
